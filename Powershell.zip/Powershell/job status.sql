use msdb
go
SELECT 
    j.name AS JobName, server,
    h.run_status AS LastRunStatus, 
   --- h.run_date AS LastRunDate, 
    FORMAT(
        CAST(
            CONVERT(VARCHAR, h.run_date) + ' ' + 
            RIGHT('0' + CAST(h.run_time / 10000 AS VARCHAR(2)), 2) + ':' + 
            RIGHT('0' + CAST((h.run_time % 10000) / 100 AS VARCHAR(2)), 2) + ':' + 
            RIGHT('0' + CAST(h.run_time % 100 AS VARCHAR(2)), 2) 
            AS DATETIME
        ), 
        'MM/dd/yyyy hh:mm:ss tt'
    ) AS LastRunTime,
    CASE 
        WHEN h.run_status = 0 THEN 'Failed' 
        WHEN h.run_status = 1 THEN 'Succeeded' 
        WHEN h.run_status = 2 THEN 'Retry' 
        WHEN h.run_status = 3 THEN 'Canceled' 
        ELSE 'Unknown' 
    END AS JobOutcome 
FROM 
    msdb.dbo.sysjobs AS j 
INNER JOIN 
    msdb.dbo.sysjobhistory AS h ON j.job_id = h.job_id 
WHERE 
    h.instance_id = (
        SELECT MAX(h2.instance_id) 
        FROM msdb.dbo.sysjobhistory h2 
        WHERE h2.job_id = j.job_id
    ) 
    AND j.name LIKE 'DBA%' 
ORDER BY 
    h.run_date DESC, h.run_time DESC;
